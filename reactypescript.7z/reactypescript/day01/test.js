// 联合类型
var uName = "45";
uName = 45;
console.log(uName);
// Array
var arrOfNumbers = [1, 2, 3];
var arrayOfNumber = [4, 5, 6];
//元祖
var arr = ["", 2, false];
var whjImpl = {
    name: "",
    age: 12,
    id: 12345
};
//函数 - 函数声明
function add(a, b, c) {
    if (c === void 0) { c = 10; }
    return a + b + c;
}
add(1);
//函数 - 函数表达式
var xx = function (a, b, c) {
    if (c === void 0) { c = 10; }
    return a + b + c;
};
//函数类型的定义
var yy = xx; //该箭头是ts中特有的
var Animal = /** @class */ (function () {
    function Animal(name, age) {
        this.name = name;
        this.age = age;
    }
    Animal.prototype.run = function () {
        console.log("开炮.....");
    };
    return Animal;
}());
var animal = new Animal("Dog", 12);
animal.run();

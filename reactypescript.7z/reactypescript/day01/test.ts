// 联合类型
let uName: string | number = "45";
uName = 45;
console.log(uName);

// Array
let arrOfNumbers:number[] = [1,2,3];
let arrayOfNumber:Array<Number> = [4,5,6];

//元祖
let arr:[string,number,boolean] = ["",2,false];

//接口（描述对象的长相）
interface IWhj {
  name:string;
  age:number;
  sex?:string;//可选属性
  readonly id: number; //只读属性  readonly只能用在属性上
}
let whjImpl:IWhj = {
  name:"",
  age:12,
  id:12345
};

//函数 - 函数声明
function add(a:number,b?:number,c:number=10):number { //可选参数  默认参数也是一种可选参数
  return a+b+c;
}
add(1);

//函数 - 函数表达式
const xx = function(a:number,b?:number,c:number=10):number { //可选参数  默认参数也是一种可选参数
  return a+b+c;
};
//函数类型的定义
let yy: (a:number,b?:number,c?:number)=>number = xx; //该箭头是ts中特有的


//类：注意类中有只读属性修饰符
//注意类的静态属性和方法
class Animal{
  private name:string;
  private age:number;
  readonly sex:string; //只读
  public static hobby:string [];
  constructor(name:string,age:number) {
    this.name = name;
    this.age =age;
  }
  public run():void{
    console.log("开炮.....");
  }
}
let animal:Animal = new Animal("Dog",12);
let y:boolean = animal instanceof Animal; //类型判断
animal.run();

class Cat extends Animal{
  constructor(name:string,age:number) {
    super(name,age);
  }
  public run():void{
    super.run();
  }
}
let cat:Cat = new Cat("cat",45);
cat.run();


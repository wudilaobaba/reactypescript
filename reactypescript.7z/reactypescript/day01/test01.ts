// 接口被类实现
interface Radio {
  switchRadio(trigger:boolean): void;
}

class Car implements Radio{
  public switchRadio(trigger: boolean): void {
    console.log("Car ...")
  }
}

class CellPhone implements Radio{
  public switchRadio(trigger: boolean): void {
    console.log("CellPhone ...")
  }
}
let a:Radio = new CellPhone();
a.switchRadio(false);


//枚举 建议在enum前加const
enum Direction{
  Up = "UP",
  Down = "DOWN",
  Left = "LEFT",
  Right = 900
}
console.log(Direction.Up);//返回数字
console.log(Direction[900]);//返回描述


//泛型 一般都是在使用的时候传入类型
//泛型方法
function exho<T>(arg:T) {
  return arg;
}
let string = exho("d");//类型推论

function swap<T,U>(t:[T,U]):[T,U] {
  return [t[0],t[1]];
}

//泛型约束
interface IWithLength {
  length:number;
}
//参数中必须有IWithLength中的属性
function echoWithArray<T extends IWithLength>(arg:T):T {
  console.log(arg.length);
  return arg;
}
echoWithArray("str");
echoWithArray([]);
echoWithArray({length:2});


//泛型类
class Queue<T>{
  private data:T[];
  public push(item:T){
    return this.data.push(item);
  }
  public pop():T{
    return this.data.shift();
  }
}
let queue:Queue<string> = new Queue<string>();
queue.push("qq");
queue.push("str");
console.log(queue.pop());

// 泛型接口
interface My<T,U> {
  a:T,
  b:U
}
let t:My<string,number> = {
  a:"",
  b:0
};



//类型别名
//没用类型别名时：
function sum(x:number,y:number):number {
  return x+y;
}
const sum2:(x:number,y:number)=>number = sum;

//用了类型别名时：
type PlusType = (x:number,y:number)=>number;
function sum3(x:number,y:number):number {
  return x+y;
}
const sum4:PlusType = sum3;

//联合类型
type X = ()=>string;
type Arg = string | X;
function xx(n:Arg):string {
  if(typeof n === 'string'){
    return n;
  }else{
    return n();
  }
}

//联合类型的类型断言as
function Peek(input:string|number):number {
  const str = input as string;//断言1。
  const s = <string>input;//断言2。
  if(str.length){
    return str.length;
  }else{
    let num = input as number;
    return num;
  }
}

//声明文件
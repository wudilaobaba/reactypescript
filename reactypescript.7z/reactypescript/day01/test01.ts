// 接口被类实现
interface Radio {
  switchRadio(trigger:boolean): void;
}

class Car implements Radio{
  public switchRadio(trigger: boolean): void {
    console.log("Car ...")
  }
}

class CellPhone implements Radio{
  public switchRadio(trigger: boolean): void {
    console.log("CellPhone ...")
  }
}
let a:Radio = new CellPhone();
a.switchRadio(false);


import React,{useState,  useEffect} from "react";
const useUrlLoader = (url:string,deps:any[] = [])=>{//deps 如果调用方参数deps发生了变那么就会重新执行该方法！！！
  const [data,setData] = useState<any>(null);
  const [loading,setLoading] = useState(false);
  useEffect(()=>{
    setLoading(true);
    //此处可以写axios
    setTimeout(()=>{
      setData([url]);
      setLoading(false);
    },2000);
  },deps);
  return [data,loading];
};
export default useUrlLoader;

import React,{useContext} from "react"
import {themeContext} from "../App"
const UseContextTest:React.FC = ()=>{
  const theme = useContext(themeContext);
  console.log("---->",theme);
  return (
    <h1 style={{color:theme.color}}>啦啦啦</h1>
  );
};
export default UseContextTest;

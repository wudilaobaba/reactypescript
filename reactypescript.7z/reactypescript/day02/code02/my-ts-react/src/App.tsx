import React,{useState,useEffect,useRef} from 'react';
import useUrlLoader from "./hocks/useUrlLoader";
import UseContextTest from "./component/UseContextTest"
//List对象的定义接口
interface ITheameProps{
  [key:string]:{color:string; background:string};
}
const theme:ITheameProps = {
  'dark':{
    color:"red",
    background:"#eee"
  },
  'light':{
    color:"green",
    background:"#f00"
  },
};
export const themeContext = React.createContext(theme.light);




const App:React.FC = ()=> {
  //!!!可以使用多个useEffect
  const didMountRef = useRef(false);//设置初始值
  useEffect(()=>{
    if(didMountRef.current){
      console.log("this is updated");
    }else{
     didMountRef.current = true;
    }
  });

  const domRef = useRef<HTMLInputElement>(null);
  useEffect(()=>{
    if(domRef && domRef.current){
      domRef.current.focus();
      console.log(domRef.current);
    }
  });


  const [show,setShow] = useState(true);
  const [times,setTimes] = useState(0);
  //使用useRef 保证取到的是数据的最终值
  const timesRef = useRef(0);


  const [data,loading] = useUrlLoader("132456",[show]);
  console.log("-->",data,loading);


  function clickHandler(){
    setTimeout(()=>{
      // alert(times)
      alert(timesRef.current);//此时可以保证数据的最终一致性
    },2000)
  }









  return (
    <>
      <themeContext.Provider value={theme.light}>

        <button onClick={()=>{setShow(!show)}}>click</button>
        {show && <span>xxxxxxxxxxx</span>}

        {loading?<h2>Loading...</h2>:<h1>success</h1>}

        {/*测试state props数据的独立性 点击该按钮，输入框就进入focus状态 */}
        <button onClick={()=>{setTimes(times+1); timesRef.current++}}>{times}</button>
        <button onClick={clickHandler}>click..</button>


        <input type={"test"} ref={domRef}/>

        <UseContextTest/> {/*themeContext包裹的组件都可以使用其value值*/}
      </themeContext.Provider>
    </>
  );
};

export default App;

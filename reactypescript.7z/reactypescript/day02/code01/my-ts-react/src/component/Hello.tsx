import React from "react"

//这里是props的泛型
interface IHelloProps {
  message?:string;
}
//React.FunctionComponent 的 类型别名：React.FC
const Hello:React.FC<IHelloProps> = (props)=>{
  return <h1>{props.message}</h1>
};
Hello.defaultProps = {
  message:"sadsadsadsa"
};
export default Hello;

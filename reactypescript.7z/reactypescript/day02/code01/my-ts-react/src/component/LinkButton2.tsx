import React,{useState, useEffect} from "react";
import useMousePosition from "../hocks/UseMousePosition";

const LinkButton2:React.FC = ()=>{
  //当有一个数据时候
  // let [like,setLike] = useState(0);
  // return(
  //     <button onClick={()=>{setLike(like+1)}}>
  //       {like}赞
  //     </button>
  // )

  //当有多个数据时：第一种处理方式
  // let [obj,setObj] = useState({like:0,on:true});
  // return(
  //     <button onClick={()=>{setObj({like:obj.like+1,on:!obj.on})}}>
  //       {obj.like}赞 ----- {obj.on+""}
  //     </button>
  // )

  //当有多个数据时：第二种处理方式
  let [like,setLike] = useState(0);//参数是初始化单个数据值
  let [on,setOn] = useState(true);//参数是初始化单个数据值
  useEffect(()=>{
    console.log("页面发生变化了.......");
    //每次页面渲染后执行一些操作
    document.title = "好困 ！！！！！！"+like;
  },[like]);//只当like变化，才执行useEffect中的逻辑



  const positions = useMousePosition();
  return(
      <div>
        <button onClick={() => {setLike(like + 1)}}>
          {like}赞
        </button>
        <button onClick={() => {setOn(!on)}}>
          {on?"ON":"OFF"}
        </button>
        <h2>{positions.x} --- {positions.y}</h2>
      </div>
  );

};
export default LinkButton2;

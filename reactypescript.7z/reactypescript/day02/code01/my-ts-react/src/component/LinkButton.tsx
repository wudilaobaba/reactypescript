import React,{useState} from "react";

const LinkButton:React.FC = ()=>{
  //当有一个数据时候
  // let [like,setLike] = useState(0);
  // return(
  //     <button onClick={()=>{setLike(like+1)}}>
  //       {like}赞
  //     </button>
  // )

  //当有多个数据时：第一种处理方式
  // let [obj,setObj] = useState({like:0,on:true});
  // return(
  //     <button onClick={()=>{setObj({like:obj.like+1,on:!obj.on})}}>
  //       {obj.like}赞 ----- {obj.on+""}
  //     </button>
  // )

  //当有多个数据时：第二种处理方式
  let [like,setLike] = useState(0);//参数是初始化单个数据值
  let [on,setOn] = useState(true);//参数是初始化单个数据值
  return(
      <div>
        <button onClick={() => {setLike(like + 1)}}>
          {like}赞
        </button>
        <button onClick={() => {setOn(!on)}}>
          {on?"ON":"OFF"}
        </button>
      </div>


  );
};
export default LinkButton;

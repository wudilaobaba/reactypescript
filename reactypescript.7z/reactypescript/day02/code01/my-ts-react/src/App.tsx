import React,{useState} from 'react';
import Hello from "./component/Hello"
import LinkButton2 from "./component/LinkButton2"
import MouseTrigger from "./component/MouseTrigger"
import useMousePosition from "./hocks/UseMousePosition";

const App:React.FC = ()=> {
  const positions = useMousePosition();
  const [show,setShow] = useState(true);
  return (
    <div>
      {/*使用自定义Hook*/}
      <h1>{positions.x}----{positions.y}</h1>



      <Hello message={"666"}/>
      <LinkButton2/>

      <button onClick={() => {setShow(!show)}}>show/hide Position</button>
      {show && <MouseTrigger/>}
    </div>
  );
}

export default App;

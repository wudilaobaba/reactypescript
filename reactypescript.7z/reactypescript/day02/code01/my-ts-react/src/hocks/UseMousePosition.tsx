import React,{useState,  useEffect} from "react";
const useMousePosition = ()=>{
  const [positions,setPositions] = useState({x:0 ,y:0});
  useEffect(()=>{
    //页面一加载会执行return之前的逻辑 配个App.tsx中隐藏该组件，该组件隐藏后会执行后面的return中的逻辑
    console.log("添加effect",positions.x);
    const updateMouse = (e:MouseEvent)=>{
      console.log("inner");
      setPositions({x:e.clientX,y:e.clientY});
    };
    document.addEventListener("mousemove",updateMouse);
    return ()=>{
      //渲染完后，执行的操作.............................................
      console.log("移除 effect",positions.x);
      document.removeEventListener("mousemove",updateMouse);
    }
  },[]);//return中后面的参数可以提高性能
  return positions;
};

export default useMousePosition;

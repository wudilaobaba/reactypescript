import React, {useState,useEffect} from "react";
interface Whj{
  name:string;
}
const Header:React.FC<Whj> = (props)=>{
  const [age,setAge] = useState(12);
  //1. 组件一加载就执行里面return前的方法
  useEffect(()=>{
    console.log(age);
    return ()=>{
      console.log("OK")
    }
  },[age]);//2. 当检测到state中age变化时，就先执行return后的方法，在重新执行一遍return前的方法
  return (
      <>
        <h1 onClick={()=>{setAge(age+1)}}>{props.name}:{age}</h1>
      </>
  );
};
Header.defaultProps = {
  name:"sssd",
};
export default Header;
/**
 * 总结：
 * 检测到state中数据变化时，就会走useEffect中绑定了变化变量的useEffect方法中，如果检测到多个state发生变化，
 * 就会执行多个useEffect方法，先执行所有变化了的useEffect的return方法，再执行变化了的useEffect中的return前的方法
 * 如果useEffect没有绑定state变量，那么一旦检测到state变化，就会执行所有未绑定state的useEffect方法
 */

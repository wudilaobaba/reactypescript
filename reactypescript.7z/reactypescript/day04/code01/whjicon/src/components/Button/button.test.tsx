import React from "react";
import {render, fireEvent} from "@testing-library/react";
import Button from "./index";
// test("xx",()=>{
//   const wraper = render(<Button>Nice</Button>);
//   const element = wraper.queryByText("Nice");
//   expect(element).toBeTruthy();
//   expect(element).toBeInTheDocument();
// });


const defaultProps = {
  onClick : jest.fn()
};

//分类测试
describe("test Button Component",()=>{
  it("aaa",()=>{
    const wraper = render(<Button {...defaultProps}>Nice</Button>);
    const element = wraper.getByText("Nice");
    expect(element).toBeInTheDocument();//element就是一个dom元素
    expect(element.tagName).toEqual("BUTTON");
    expect(element).toHaveClass("btn");

    //测试组件上的onClick测试
    fireEvent.click(element);
    expect(defaultProps.onClick).toHaveBeenCalled();
  });
  it("bbb",()=>{

  });
  it("ccc",()=>{

  });
});

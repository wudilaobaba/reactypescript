import React from "react";
import classNames from "classnames";
export enum ButtonSizes{
  Large = "lg",
  Small = "sm"
}
export enum ButtonType {
  Primary = "primary",
  Default = "default",
  Danger = "danger",
  Link = "link"
}
// 定义该组件的props属性类型
interface BaseButtonProps {
  className?:string;
  disabled?:boolean;
  size?:ButtonSizes;
  btnType?:ButtonType;
  href?:string,
  children:React.ReactNode;
}
type NativeButtonProps = BaseButtonProps & React.ButtonHTMLAttributes<HTMLElement>; //react提供的原生button类型
type AnchorButtonProps = BaseButtonProps & React.AnchorHTMLAttributes<HTMLElement>; //react提供的原生a标签类型
export type ButtonProps = Partial<NativeButtonProps & AnchorButtonProps>; //此时button和a上都会有react原生的onClick属性了
const Button:React.FC<ButtonProps> = (props)=>{
 // restProps就是对象中的其他属性
 const {btnType, className, disabled, size, children, href,...restProps} = props;
 const classes = classNames("btn",{ //"btn"是一个默认样式
   [`btn-${btnType}`]:btnType,
   [`btn-${size}`]:size,
   'disabled':(btnType === ButtonType.Link) && disabled
 });
 if(btnType === ButtonType.Link && href){
    return (
        <a
            className={classes}
            href={href}
            {...restProps}
        >
          {children}
        </a>
    )
 }
  return(
      <button
          className={classes}
          disabled={disabled}
          {...restProps}
      >{children}</button>
  )
};
//设置该组件的默认props的值
Button.defaultProps = {
  disabled:false,
  size:ButtonSizes.Small,
};
export default Button;

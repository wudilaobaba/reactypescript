import React,{useState} from 'react';
import AutoCompoleteProps from "./components/AutoComplete"


function App() {
  return (
    <>
      <AutoCompoleteProps
        fetchSuggestions={(a:string)=>["1","2"]}
      />
    </>
  );
}

export default App;

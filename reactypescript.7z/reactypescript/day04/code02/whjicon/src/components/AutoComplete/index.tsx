import React, {ChangeEvent, FC, useState} from "react";
import Input,{InutProps} from "../Input";
export interface AutoCompoleteProps extends Omit<InutProps,"onSelect"> {
  fetchSuggestions:(str:string)=>string[];//根据当前输入框的值进行操作(必须调用)
  onSelect?:(item:string)=>void;
}
export const AutoCompolete:FC<AutoCompoleteProps> = (props)=>{
  const {fetchSuggestions,value,onSelect,...restprops} = props;
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [inputVal,setInputVal] = useState(value);
  const handleChange = (e:ChangeEvent<HTMLInputElement>)=>{
    const val = e.target.value.trim();
    setInputVal(val);
    if(val){
      const result:string[] = fetchSuggestions(val);
    }
  };
  return(
      <>
        <Input
            value={value}
            {...restprops}
            onChange={handleChange}
        />
      </>
  )
};
export default AutoCompolete;

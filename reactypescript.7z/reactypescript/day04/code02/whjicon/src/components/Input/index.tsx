import React, {ReactElement, InputHTMLAttributes, ChangeEvent} from "react";
type InputSize = "sm"|"lg";
export interface InutProps extends Omit<InputHTMLAttributes<HTMLElement>,"size">{
  size?:InputSize;
  prepand?:string | ReactElement;
  append?:string | ReactElement;
  onChange?:(e:ChangeEvent<HTMLInputElement>) => void;
}
const Index:React.FC<InutProps> = (props)=>{
  const {prepand,append,size,children,onChange,...others} = props;
  return(
      <>
        {prepand}
        <input
            {...others}
            onChange={onChange}
        />
        {append}
        {JSON.stringify({
          size
        })}
      </>
  )
};
export default Index;

import React,{useState} from "react";
export enum AlertType{
  Success = "success",
  Defaults = "defaults",
  Danger = "danger",
  Waring = "waring"
}
interface AlertBaseProps {
  title?:string;
  context?:string;
  canBeClose?:boolean;
  type?:AlertType
}
type NativeAlertProps = AlertBaseProps & React.DelHTMLAttributes<HTMLElement>;
const Alert:React.FC<NativeAlertProps> = (props)=>{
  const [close, setClose] = useState(true);
  const {title,context,canBeClose,type,...respProps} = props;
  return (
      <>
        {
          close
          &&
          <div {...respProps} style={{border:"solid 1px red",marginBottom:"100px"}}>
            <h1>{title} - {type}</h1>
            <div>{context}</div>
            {canBeClose && <div onClick={()=>{setClose(false)}}>关闭</div>}
          </div>
        }
      </>
  )
};
Alert.defaultProps = {
  title:"提示",
  canBeClose:false,
  type:AlertType.Defaults
};
export default Alert;

import React from 'react';
import Button, {ButtonType} from "./components/Button";
import Alert,{AlertType} from "./components/Alert";
import Menu from "./components/Menu";
import MenuItem from "./components/Menu/menuItem";
import SubMenu from "./components/Menu/subMenu"


function App() {
  // title?:string;
  // context?:string;
  // canBeClose?:boolean;
  // type?:AlertType
  return (
    <>
      <Alert title={"真会说"} context={"这几是都会杀菌灯很快就啥的空间撒谎的"} canBeClose={true} type={AlertType.Waring}/>
      <Button
          autoFocus={true}
          onClick={()=>alert(123)}
      >
        默认
      </Button>

      <Button btnType={ButtonType.Primary}>PRIMARY</Button>
      <Button disabled={true}>禁用</Button>
      <Button
          btnType = {ButtonType.Danger}
      >danger</Button>
      <Button
        btnType={ButtonType.Link}
        href={"http://www.baidu.com"}
      >go to baidu</Button>
      <Menu onSelect={(index)=>{console.log(index)}} mode={"vertical"}>
        <MenuItem>1</MenuItem>
        <SubMenu title={"xxx"}>
          <MenuItem>2</MenuItem>
          <MenuItem>3</MenuItem>
        </SubMenu>
        <MenuItem>4</MenuItem>
      </Menu>
    </>
  );
}

export default App;
